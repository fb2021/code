#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 15 16:14:39 2020

@author: mha
"""


import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
from sklearn import metrics


xtrain = np.load("xtrain.npy")
ytrain = np.load("ytrain.npy")

xtrain, xtest, ytrain, ytest = train_test_split(xtrain, ytrain, 
                                              test_size = 0.25)
y_true=ytest

svclassifier = SVC(kernel='rbf')
svclassifier.fit(xtrain, ytrain)

ypred = svclassifier.predict(xtest)

print(confusion_matrix(ytest,ypred))
print(classification_report(ytest,ypred))

#ypred = svclassifier.predict_proba(xtest)[::,1]
fpr, tpr, _ = metrics.roc_curve(y_true,  ypred)
auc = metrics.roc_auc_score(y_true, ypred)
plt.plot(fpr,tpr,label="data 1, auc="+str(auc))
plt.legend(loc=4)
plt.show()
#y_pred_proba = model.predict_proba(xtest)[::,1]
