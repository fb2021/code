#import socket
import pandas as pd
#from ipwhois import IPWhois
#import struct
from sklearn.model_selection import StratifiedKFold
import numpy as np
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
from sklearn.metrics import (precision_score, recall_score,f1_score, accuracy_score)
from sklearn.model_selection import train_test_split


conf_mat = []

seed=20
np.random.seed(seed)
#import networkx as nx
df=pd.read_csv(r"C:/Users/faba/Desktop/dataset50.1.csv")
ds=pd.read_csv(r"C:/Users/faba/Desktop/Domain_ip_graph.csv")
#print(df)
#print(ds)
print("*********************************************")

#df=pd.read_csv(r"mb.csv")
#print(df)
df=df.as_matrix()
ds=ds.as_matrix()
#####################################################
#def cidr_to_netmask(cidr):
    #network, net_bits = cidr.split('/')
    #host_bits = 32 - int(net_bits)
    #netmask = socket.inet_ntoa(struct.pack('!I', (1 << 32) - (1 << host_bits)))
    #return network, netmask
#cidr_to_netmask('85.185.64.0/22')

domainList = []
labelsList = []
ip_addresses={}
labels = {}
#asns = {}
#cidrs = {}
#netmasks = {}
for i in df:
    x=i[0].lower()
    #print(x)
    if "orcid.org"==x:
        print("-----------")
        print(i)
        print("-----------")
#    print(i[0])
#    print(i[1])
#    print('----')
    if i[1] == 0:
        labels[x] = 0
        labelsList.append(0)
        domainList.append(x)
    else:
        labels[x] = 1
        labelsList.append(1)
        domainList.append(x)        
for l in ds:
        temp = []
        ip_address_list = l
        if ip_address_list[0].lower() in ip_addresses.keys():
            ip_addresses[ip_address_list[0].lower()].append(ip_address_list[1])
        else:
            temp.append(ip_address_list[1])
            ip_addresses[ip_address_list[0].lower()] = temp
    
        
    
          

        #temp_cidr = []
        #temp_netmask = []
        #asn = {}
        #for ip_address in ip_address_list[2]:
            #ipwhois=IPWhois(ip_address)
            #asn[ip_address] = ipwhois.net.get_asn_dns()[0].to_text().split('|')[0].split('"')[1].strip()
            #cidr = ipwhois.net.get_asn_dns()[0].to_text().split('|')[1]
            #temp_cidr.append(cidr)
            #network, netmask = cidr_to_netmask(cidr)
            #temp_netmask.append(netmask)
        #asns[ip_address_list[0]] = asn
        #cidrs[ip_address_list[0]] = temp_cidr
        #netmasks[ip_address_list[0]] = temp_netmask
    #except:
        #print("You cannot! ",i[0])
#print(labels["vip-lb.wordpress.com"])
#######################################################################
class Node:
    def __init__(self, name=None, name_type=None):
        self.name = name
        self.name_type = name_type



class Vertex:
    def __init__(self,key):
        self.id = key
        self.connectedTo = {}
        # self.connectedToVertex = {}

    # def addConnect(self,nbr, nbr1):
    #     if len(self.connectedToVertex) == 0 or (nbr not in self.connectedToVertex.keys()):
    #         self.connectedToVertex[nbr] = [0, [nbr1]]
    #     else:
    #         temp = self.connectedToVertex[nbr]
    #         temp[0] = temp[0] + 1
    #         temp[1] = temp[1].append(nbr1)
    #         self.connectedToVertex[nbr] = temp
    
    def addNeighbor(self,nbr,weight=0):
        self.connectedTo[nbr] = weight

    def __str__(self):
        return str(self.id) + ' connectedTo: ' + str([x.id for x in self.connectedTo])

    def getConnections(self):
        return self.connectedTo.keys()

    def getId(self):
        return self.id

    def getWeight(self,nbr):
        return self.connectedTo[nbr]



################################################################
class Graph:
    def __init__(self):
        self.vertList = {}
        self.numVertices = 0
        self.connectedToVertex = {}

    def addVertex(self,key):
        self.numVertices = self.numVertices + 1
        newVertex = Vertex(key)
        self.vertList[key] = newVertex
        return newVertex

    def getVertex(self,n):
        if n in self.vertList:
            return self.vertList[n]
        else:
            return None

    def __contains__(self,n):
        return n in self.vertList

    def addEdge(self,f,t,weight=0):
        if f not in self.vertList:
            nv = self.addVertex(f)
        if t not in self.vertList:
            nv = self.addVertex(t)
        self.vertList[f].addNeighbor(self.vertList[t], weight)
        # self.vertList[f].addConnect(t, f)
        
        # print(self.connectedToVertex)
        # print(len(self.connectedToVertex))
        # if (t in self.connectedToVertex.keys()):
        #     print(t)
        #     print(f)
        #     print(self.connectedToVertex[t])
        #     print(t)
        #     print(self.connectedToVertex.keys())
        if len(self.connectedToVertex) == 0:
            self.connectedToVertex[t] = [1, [f]]
        elif (t not in self.connectedToVertex.keys()):
            self.connectedToVertex[t] = [1, [f]]
        else:
            # print(t)
            # print(f)
            # print(self.connectedToVertex[t])
            temp = self.connectedToVertex[t]
            # print(temp)
            # print(temp[0])
            # print(temp[1])
            countConnection = temp[0] + 1
            # print('temp[0]' + str(countConnection))
            connection = temp[1]
            # print('temp[1]' + str(temp1))
            connection.append(f)
            self.connectedToVertex[t] = [countConnection, connection]
        # print(self.connectedToVertex)
        

    def getVertices(self):
        return self.vertList.keys()

    def __iter__(self):
        return iter(self.vertList.values())


################################################################################


    
domain_ip_graph = Graph()
        
dict_ip_private={}
dict_ip_public={}
temp=True
ip_dict = {}

for counter in ip_addresses.keys():
#for counter in train_features:
# for iprivate in a:
    iprivate = ip_addresses[counter]
    private = []
    public = []
    for i in iprivate:
        temp = int(i.replace('.',''))
        if ((temp>=127000 and temp<=255000)
            or (temp>=19216800 and temp<=25525500)
            or (temp>=1721600 and temp<=25524000)
            or (temp>=10000 and temp<=255000)):
            if i not in ip_dict.keys():
                ip_dict[i] = Node(i,'private')
            private.append(i)
            domain_ip_graph.addEdge(counter, ip_dict[i].name)
        else:
            if i not in ip_dict.keys():
                ip_dict[i] = Node(i,'public')
            public.append(i)
            domain_ip_graph.addEdge(counter, ip_dict[i].name)
    
    dict_ip_private[iprivate[0]] = []
    dict_ip_public[iprivate[0]] = []        
    if len(private) != 0:
        dict_ip_private[iprivate[0]] = private
    if len(public) != 0:
        dict_ip_public[iprivate[0]] = public
        


    
    
#for i in domain_ip_graph.connectedToVertex.keys():
    #s = i
    #for j in domain_ip_graph.connectedToVertex[i][1]:
       # s = s + " --> " + j
    #print(s)
    
#for v in domain_ip_graph:
     #for w in v.getConnections():
        #print("( %s , %s )" % (v.id, w.id))

        
 ###################################################################       
        
def calculate_weight(a,b): 
    q=set(ip_addresses[a])
    z=set(ip_addresses[b])
    eshterac=q.intersection(z)
    # print(eshterac)
    w = 1- (1/(1+len(eshterac)))
    return w
    #ic()
                
        
        
#G-baseline:        
        
domain_graph_Gbaseline = Graph()
#dict_baseline={}
b_list=[]
item=True

for k in domain_ip_graph.connectedToVertex.keys():
    # print(k)
    # print( domain_ip_graph.connectedToVertex.values())
    # print('------------')
    b_list=domain_ip_graph.connectedToVertex[k]
    # print(k)
    # print(b_list)
    # print('----')
    
    if b_list[0]==1:
#        domain_graph_Gbaseline.addEdge(b_list[1][0],b_list[1][0])
        pass
        
    else:
         for item in range(len(b_list[1])):
            for itemm in range(len(b_list[1])):
                  if item==itemm:
                      pass
                  else:
                      weight = calculate_weight(b_list[1][item],b_list[1][itemm])
                      domain_graph_Gbaseline.addEdge(b_list[1][item],b_list[1][itemm],1)



# BP algoritm            

phi_malicious_node_i = {
        0:0.01,
        1:0.99,
        -1:0.5}

delta_node_i_j = {
        'equal':0.51}
    






domainList = list(domain_graph_Gbaseline.connectedToVertex.keys())
labelsList = [labels[x] for x in domainList]



kfold = StratifiedKFold(n_splits=6, shuffle=True, random_state=seed)
cvscores = []
conf_mat = []
accuracy=[]
domainList = np.array(domainList)
labelsList = np.array(labelsList)
# for train, test in kfold.split(domainList, labelsList):
    
#     train_features = domainList[train]
#     train_labels = labelsList[train]
#     test_features = domainList[test]
#     test_labels = labelsList[test]

train_features, test_features, train_labels, test_labels = train_test_split(domainList, labelsList, 
                                              test_size = 0.1)
y_true=train_labels
y_pred=test_labels
m = {}

for key in domain_graph_Gbaseline.connectedToVertex.keys():
#    for key in train_features:
    neighbors = domain_graph_Gbaseline.connectedToVertex[key][1]
    for neighbor in neighbors:
        m[neighbor + '-' + key] = 1


def getDelta(key, neighbor):
    if labels[key] == labels[neighbor]:
        delta = delta_node_i_j['equal']
    else:
        delta = 1 - delta_node_i_j['equal']
    return delta

def getMultiply(key, neighborList, neighbor):
    multiply = 1
    for i in neighborList:
        if not i == neighbor and not i == key:
#            print(i + '-' + key)
#            print(m[i + '-' + key])
            multiply = multiply * m[i + '-' + key]
#    print('multiply ' + i + '-' + key + ' = ' + str(multiply))
    return multiply

for loop in range(1):
#        for key in domain_graph_Gbaseline.connectedToVertex.keys():
    for key in train_features:
#        print('key = ', key)
        neighbors = domain_graph_Gbaseline.connectedToVertex[key][1]
        for neighbor in neighbors:
#            print('neighbor = ', neighbor)
            if key == neighbor:
                pass
            else:
                m[neighbor + '-' + key] = (phi_malicious_node_i[labels[key]] * 
                     getDelta(key,neighbor) *
                     getMultiply(key, neighbors, neighbor)) + ((1 - phi_malicious_node_i[labels[key]]) *
                       getDelta(key,neighbor) *
                       getMultiply(key, neighbors, neighbor))
    
#                print('*****')
#                print('first = ', (phi_malicious_node_i[labels[key]] * 
#                         getDelta(key,neighbor) *
#                         getMultiply(key, neighbors, neighbor)))
#                print('second = ', ((1 - phi_malicious_node_i[labels[key]]) *
#                           getDelta(key,neighbor) *
#                           getMultiply(key, neighbors, neighbor)))
#                print(m[neighbor + '-' + key])
#                print('*****')
#                print('-----------------------------------------------------')
            
   
#
#b={}
## tekrare Akhar          
#for d in range(len(m.keys())) :  
#   b=(1*phi_malicious_node_i[labels[key]])* d
#   print( b)
#   if b>=0.75:
#        labels[key]=1
#       
#   else:
#         labels[key]=0
         


def getMultiply_for_b(key, neighborList):
    multiply = 1
    for i in neighborList:
        if not i == key:
            multiply = multiply * m[key + '-' + i]
    return multiply
 ########################################################################################   

b = {}

#    for key in m.keys():
for key in test_features:
    orginal_key = key.split('-')[0]
    b[orginal_key] = []

#    for key in m.keys():
for key in test_features:
    
#        orginal_key = key.split('-')[0]
    orginal_key = key
#        neighbor_key = key.split('-')[1]
    neighbors = domain_graph_Gbaseline.connectedToVertex[orginal_key][1]
#        multiply = getMultiply_for_b(orginal_key, neighbors, neighbor_key)
    multiply = getMultiply_for_b(orginal_key, neighbors)
    finall_b = 0.5 * multiply
    if finall_b >= 0.25:
        b[orginal_key].append(1)
    else:
        b[orginal_key].append(0)

finall_labels = {}
finall_labels_test = []
for key in b.keys():
    b_list = b[key]
    if b_list.count(0) > b_list.count(1):
        finall_labels[key] = 0
        finall_labels_test.append(0)
    else:
        finall_labels[key] = 1
        finall_labels_test.append(1)


conf_mat.append(confusion_matrix(test_labels, finall_labels_test))
res = sum(x == y for x, y in zip(test_labels, finall_labels_test))
acc = (res/len(test_labels) * 100)
accuracy.append(acc)
print(accuracy)
print(acc)

'''
accuracy = accuracy_score(test_labels, finall_labels_test)
recall = recall_score(test_labels, finall_labels_test , average="weighted")
precision = precision_score(test_labels, finall_labels_test , average="weighted")
f1 = f1_score(test_labels, finall_labels_test, average="weighted")
'''
accuracy = 0
if float(np.sum(conf_mat))!=0:
    accuracy = float(conf_mat[0,0]+conf_mat[1,1])/float(np.sum(conf_mat))
#recall = 0
if float(conf_mat[0,0]+conf_mat[1,0])!=0:
    recall = float(conf_mat[0,0])/float(conf_mat[0,0]+conf_mat[1,0])
#precision = 0
if float(conf_mat[0,0]+conf_mat[0,1])!=0:
    precision = float(conf_mat[0,0])/float(conf_mat[0,0]+conf_mat[0,1])
#F1 score
f1 = f1_score(y_true, y_pred, average="weighted")
print("confusion matrix")
print("----------------------------------------------")
print("accuracy")
print("%.3f" %accuracy)
print("racall")
print("%.3f" %recall)
print("precision")
print("%.3f" %precision)
print("f1score")
print("%.3f" %f1)





















